const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 8080;
const LOG_FILE_PATH = path.join(__dirname, 'server.log');
const SUPPORTED_EXTENSIONS = ['.log', '.txt', '.json', '.yaml', '.xml', '.js'];

// Middleware to log every request
app.use((req, res, next) => {
  fs.appendFileSync(LOG_FILE_PATH, `[${new Date()}] ${req.method} ${req.url}\n`);
  next();
});

// Middleware to parse request body
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Routes
app.post('/createFile', (req, res) => {
  const { filename, content, password } = req.body;
  if (!filename || !content) {
    return res.status(400).send('Filename and content are required.');
  }
  const extension = path.extname(filename);
  if (!SUPPORTED_EXTENSIONS.includes(extension)) {
    return res.status(400).send('Unsupported file extension.');
  }
  if (password && typeof password !== 'string') {
    return res.status(400).send('Password must be a string.');
  }

  // Save file
  fs.writeFile(filename, content, (err) => {
    if (err) {
      return res.status(500).send('Error saving file.');
    }
    res.sendStatus(200);
  });
});

app.get('/getFiles', (req, res) => {
  fs.readdir(__dirname, (err, files) => {
    if (err) {
      return res.status(500).send('Error reading directory.');
    }
    res.json(files);
  });
});

app.get('/getFile/:filename', (req, res) => {
  const { filename } = req.params;
  const { password } = req.query;

  if (!filename) {
    return res.status(400).send('Filename parameter is required.');
  }

  const filePath = path.join(__dirname, filename);
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      return res.status(400).send('File not found.');
    }
    // Optionally check password here if implemented
    if (password) {
      // Implement password check logic here
    }
    res.send(data);
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${8080}`);
});
